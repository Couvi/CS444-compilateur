 
 Alexis BERTRAND		bertraal 		alexis.bertrand1@etu.esisar.grenoble-inp.fr
 Henri DE BOUTRAY	deboutrh		henri.deboutray@etu.esisar.grenoble-inp.fr
 Horus DAGNON		dagnonh		horus.dagnon@etu.esisar.grenoble-inp.fr
 Guillaume BRUCHON	bruchong		guillaume.bruchon@etu.esisar.grenoble-inp.fr
 
 Pour lancer les tests depuis ce dossier
	- Taper la commande "make" pour compiler 
	- Taper "make test" pour lancer les tests