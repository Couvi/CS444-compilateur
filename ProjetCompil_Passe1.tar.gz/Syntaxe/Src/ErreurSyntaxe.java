package ProjetCompil.Syntaxe.Src;

/**
 * Exception levee en cas d'erreur de syntaxe.
 */

public class ErreurSyntaxe extends Exception {

}

