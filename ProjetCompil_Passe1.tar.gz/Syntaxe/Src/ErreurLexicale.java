package ProjetCompil.Syntaxe.Src;

/**
 * Exception levee en cas d'erreur lexicale. 
 */

public class ErreurLexicale extends Exception {

}

